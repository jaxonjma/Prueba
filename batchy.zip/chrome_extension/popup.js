const tabs = document.querySelectorAll(".tab");
const whiskPanel = document.getElementById("whiskPanel");
const grokPanel = document.getElementById("grokPanel");
const geminiPanel = document.getElementById("geminiPanel");

const whiskStatusEl = document.getElementById("whiskStatus");
const whiskCookieBox = document.getElementById("whiskCookieBox");
const whiskCopyBtn = document.getElementById("whiskCopyBtn");
const whiskDot = document.getElementById("whiskDot");

const grokStatusEl = document.getElementById("grokStatus");
const grokCookieBox = document.getElementById("grokCookieBox");
const grokCopyBtn = document.getElementById("grokCopyBtn");
const grokDot = document.getElementById("grokDot");

const geminiStatusEl = document.getElementById("geminiStatus");
const geminiCookieBox = document.getElementById("geminiCookieBox");
const geminiCopyBtn = document.getElementById("geminiCopyBtn");
const geminiDot = document.getElementById("geminiDot");

let whiskCookieString = "";
let grokCookieString = "";
let geminiCookieString = "";
let currentStoreId = null;

function switchTab(target) {
  tabs.forEach((t) => {
    t.classList.toggle("active", t.dataset.tab === target);
  });
  whiskPanel.classList.toggle("active", target === "whisk");
  grokPanel.classList.toggle("active", target === "grok");
  geminiPanel.classList.toggle("active", target === "gemini");
}

tabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    switchTab(tab.dataset.tab);
  });
});

function processWhiskCookies(cookies) {
  if (!cookies || cookies.length === 0) {
    whiskStatusEl.className = "status error";
    whiskStatusEl.textContent =
      "No se encontraron cookies. Inicia sesion en labs.google/fx/tools/whisk primero.";
    whiskDot.className = "dot red";
    return;
  }

  whiskCookieString = cookies.map((c) => c.name + "=" + c.value).join("; ");

  whiskStatusEl.className = "status success";
  whiskStatusEl.textContent = cookies.length + " cookies encontradas";
  whiskDot.className = "dot green";

  whiskCookieBox.style.display = "block";
  whiskCookieBox.textContent = whiskCookieString.substring(0, 200) + "...";

  whiskCopyBtn.disabled = false;
}

function processGrokCookies(cookies) {
  if (!cookies || cookies.length === 0) {
    grokStatusEl.className = "status error";
    grokStatusEl.textContent =
      "No se encontraron cookies. Inicia sesion en grok.com primero.";
    grokDot.className = "dot red";
    return;
  }

  grokCookieString = cookies.map((c) => c.name + "=" + c.value).join("; ");

  const cookieNames = cookies.map((c) => c.name);
  const hasSso = cookieNames.includes("sso");

  if (!hasSso) {
    grokStatusEl.className = "status error";
    grokStatusEl.textContent =
      "Falta cookie 'sso'. Inicia sesion en grok.com primero.";
    grokDot.className = "dot red";
  } else {
    grokStatusEl.className = "status success";
    grokStatusEl.textContent =
      cookies.length + " cookies capturadas - OK";
    grokDot.className = "dot green";
  }

  grokCookieBox.style.display = "block";
  grokCookieBox.textContent = grokCookieString.substring(0, 200) + "...";

  grokCopyBtn.disabled = false;
}

function processGeminiCookies(cookies) {
  if (!cookies || cookies.length === 0) {
    geminiStatusEl.className = "status error";
    geminiStatusEl.textContent =
      "No se encontraron cookies. Inicia sesion en gemini.google.com primero.";
    geminiDot.className = "dot red";
    return;
  }

  const cookieMap = {};
  for (const c of cookies) {
    cookieMap[c.name] = c.value;
  }

  const psid = cookieMap["__Secure-1PSID"];
  const psidts = cookieMap["__Secure-1PSIDTS"];

  if (!psid) {
    geminiStatusEl.className = "status error";
    geminiStatusEl.textContent =
      "Falta __Secure-1PSID. Inicia sesion en gemini.google.com primero.";
    geminiDot.className = "dot red";
    return;
  }

  geminiCookieString = "__Secure-1PSID=" + psid;
  if (psidts) {
    geminiCookieString += "; __Secure-1PSIDTS=" + psidts;
  }

  geminiStatusEl.className = "status success";
  geminiStatusEl.textContent = "Cookies de Gemini encontradas - OK";
  geminiDot.className = "dot green";

  geminiCookieBox.style.display = "block";
  geminiCookieBox.textContent = geminiCookieString.substring(0, 200) + "...";

  geminiCopyBtn.disabled = false;
}

function getCookieQuery(base) {
  if (currentStoreId) {
    return Object.assign({}, base, { storeId: currentStoreId });
  }
  return base;
}

function loadWhiskCookies() {
  whiskStatusEl.className = "status loading";
  whiskStatusEl.textContent = "Buscando cookies de Whisk...";

  chrome.cookies.getAll(getCookieQuery({ domain: "labs.google" }), (cookies) => {
    if (cookies && cookies.length > 0) {
      processWhiskCookies(cookies);
    } else {
      chrome.cookies.getAll(getCookieQuery({ domain: "labs.google.com" }), (cookiesFallback) => {
        processWhiskCookies(cookiesFallback);
      });
    }
  });
}

function loadGrokCookies() {
  grokStatusEl.className = "status loading";
  grokStatusEl.textContent = "Buscando cookies de Grok...";

  const seen = new Set();
  const merged = [];

  function addCookies(cookies) {
    for (const c of (cookies || [])) {
      if (!seen.has(c.name)) {
        seen.add(c.name);
        merged.push(c);
      }
    }
  }

  function finalize() {
    processGrokCookies(merged);
  }

  function tryPartitioned() {
    try {
      chrome.cookies.getAll(
        getCookieQuery({ url: "https://grok.com", partitionKey: { topLevelSite: "https://grok.com" } }),
        (cp1) => {
          addCookies(cp1);
          try {
            chrome.cookies.getAll(
              getCookieQuery({ url: "https://grok.com", partitionKey: {} }),
              (cp2) => {
                addCookies(cp2);
                finalize();
              }
            );
          } catch (e) {
            finalize();
          }
        }
      );
    } catch (e) {
      finalize();
    }
  }

  chrome.cookies.getAll(getCookieQuery({ url: "https://grok.com" }), (c1) => {
    addCookies(c1);
    chrome.cookies.getAll(getCookieQuery({ domain: "grok.com" }), (c2) => {
      addCookies(c2);
      chrome.cookies.getAll(getCookieQuery({ domain: ".grok.com" }), (c3) => {
        addCookies(c3);
        if (!seen.has("cf_clearance")) {
          tryPartitioned();
        } else {
          finalize();
        }
      });
    });
  });
}

function loadGeminiCookies() {
  geminiStatusEl.className = "status loading";
  geminiStatusEl.textContent = "Buscando cookies de Gemini...";

  const seen = new Set();
  const merged = [];

  function addCookies(cookies) {
    for (const c of (cookies || [])) {
      if (!seen.has(c.name)) {
        seen.add(c.name);
        merged.push(c);
      }
    }
  }

  chrome.cookies.getAll(getCookieQuery({ domain: ".google.com" }), (c1) => {
    addCookies(c1);
    chrome.cookies.getAll(getCookieQuery({ url: "https://gemini.google.com" }), (c2) => {
      addCookies(c2);
      chrome.cookies.getAll(getCookieQuery({ domain: "gemini.google.com" }), (c3) => {
        addCookies(c3);
        if (!seen.has("__Secure-1PSID")) {
          chrome.cookies.getAll(getCookieQuery({ url: "https://accounts.google.com" }), (c4) => {
            addCookies(c4);
            chrome.cookies.getAll(getCookieQuery({ domain: "google.com" }), (c5) => {
              addCookies(c5);
              processGeminiCookies(merged);
            });
          });
        } else {
          processGeminiCookies(merged);
        }
      });
    });
  });
}

function copyToClipboard(text, btn, label) {
  navigator.clipboard
    .writeText(text)
    .then(() => {
      btn.textContent = "Copiado!";
      btn.className = "copied";
      setTimeout(() => {
        btn.textContent = label;
        btn.className = "primary";
      }, 2000);
    })
    .catch(() => {
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      btn.textContent = "Copiado!";
      btn.className = "copied";
      setTimeout(() => {
        btn.textContent = label;
        btn.className = "primary";
      }, 2000);
    });
}

whiskCopyBtn.addEventListener("click", () => {
  if (!whiskCookieString) return;
  copyToClipboard(whiskCookieString, whiskCopyBtn, "Copiar Cookie de Whisk");
});

grokCopyBtn.addEventListener("click", () => {
  if (!grokCookieString) return;
  copyToClipboard(grokCookieString, grokCopyBtn, "Copiar Cookie de Grok");
});

geminiCopyBtn.addEventListener("click", () => {
  if (!geminiCookieString) return;
  copyToClipboard(geminiCookieString, geminiCopyBtn, "Copiar Cookies de Gemini");
});

chrome.tabs.query({ active: true, currentWindow: true }, (activeTabs) => {
  if (activeTabs && activeTabs.length > 0) {
    const tabId = activeTabs[0].id;
    const url = activeTabs[0].url || "";

    chrome.cookies.getAllCookieStores((stores) => {
      if (stores) {
        for (const store of stores) {
          if (store.tabIds && store.tabIds.includes(tabId)) {
            currentStoreId = store.id;
            break;
          }
        }
      }

      loadWhiskCookies();
      loadGrokCookies();
      loadGeminiCookies();
    });

    if (url.includes("grok.com")) {
      switchTab("grok");
    } else if (url.includes("gemini.google.com")) {
      switchTab("gemini");
    } else if (url.includes("labs.google")) {
      switchTab("whisk");
    }
  } else {
    loadWhiskCookies();
    loadGrokCookies();
    loadGeminiCookies();
  }
});
